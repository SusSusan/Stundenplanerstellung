import random

Lehrer = ["Müller", "Warin", "Studer", "Hauck", "Hänne"]  # alle möglichen lehrer
Räume = [1, 2, 3, 4, 5]  # alle möglichen Lehrer
Montag = [[[0], [0], [0], [0], [0]],
          [[0], [0], [0], [0], [0]],
          [[0], [0], [0], [0], [0]],
          [[0], [0], [0], [0], [0]],
          [[0], [0], [0], [0], [0]]]  # Alle spalten sind Klassen und alle Zeilen sind Zeiträume für lektion

for Uhrzeit in Montag:
    for Klasse in Uhrzeit:
        lehrer = random.randint(0, 4)
        raum = random.randint(0, 4)
        Klasse[0] = [Lehrer[lehrer]]
        Klasse.append(Räume[raum])  # Es gibt jeder Klasse zur jeder Lektionen zufällig Lehrer und Raum

for X in Montag:
    for n in X:
        if n == [0]:
            print(
                'fail')  # Das ist aus einer Vorherigen Version vom Program wobei die füllenden Stunden auch zufällig waren. Dieser Prozess ging aber zulange und habe es daher nochmal vereinfacht. Dieser Checkpoint könnte trotzdem da bleiben. Das Ziel ist ja eine rekursive Funktion

M3a = [Montag[0][0], Montag[1][0], Montag[2][0], Montag[3][0], Montag[4][0]]
M3b = [Montag[0][1], Montag[1][1], Montag[2][1], Montag[3][1], Montag[4][1]]
M3c = [Montag[0][2], Montag[1][2], Montag[2][2], Montag[3][2], Montag[4][2]]
M3d = [Montag[0][3], Montag[1][3], Montag[2][3], Montag[3][3], Montag[4][3]]
M3e = [Montag[0][4], Montag[1][4], Montag[2][4], Montag[3][4], Montag[4][4]]

for x in Montag:
    print(x)