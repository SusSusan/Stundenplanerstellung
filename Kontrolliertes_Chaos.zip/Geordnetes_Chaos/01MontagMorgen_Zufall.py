import random
Lehrer = ["Müller","Warin","Studer","Hauck","Hänne"] #alle möglichen lehrer
Räume=[1,2,3,4,5] #alle möglichen Lehrer
Montagleer= [[[0,0], [0,1], [0,2], [0,3], [0,4]],
         [[1,0], [1,1], [1,2], [1,3], [1,4]],
         [[2,0], [2,1], [2,2], [2,3], [2,4]],
         [[3,0], [3,1], [3,2], [3,3], [3,4]],
         [[4,0], [4,1], [4,2], [4,3], [4,4]]] # Alle spalten sind Klassen und alle Zeilen sind Zeiträume für lektion.
Montagvoll=[[[0], [0], [0], [0], [0]],
            [[0], [0], [0], [0], [0]],
            [[0], [0], [0], [0], [0]],
            [[0], [0], [0], [0], [0]],
            [[0], [0], [0], [0], [0]]]
def Zufall():
    if len(Montagleer)==1:
        uhrz=0
    else:
       uhrz=random.randint(0,(len(Montagleer)-1))
    uhrzkls=Montagleer[uhrz][random.randint(0,len(Montagleer[uhrz])-1)]
    lehrer= random.randint(0,4)
    raum=random.randint(0,4)
    Montagvoll[uhrzkls[0]][uhrzkls[1]]=[Lehrer[lehrer]]
    Montagvoll[uhrzkls[0]][uhrzkls[1]].append(Räume[raum]) #Es gibt jeder Klasse zur jeder Lektionen zufällig Lehrer und Raum
    Montagleer[uhrz].remove(uhrzkls)#verhindert dass die selbe Klasse um die selbe Uhrzeit "umgebucht" wird.
    if len(Montagleer[uhrz])==0:
        Montagleer.remove(Montagleer[uhrz])

while len(Montagleer) != 0:
      Zufall()

M3a=[Montagvoll[0][0],Montagvoll[1][0], Montagvoll[2][0],Montagvoll[3][0],Montagvoll[4][0]]
M3b=[Montagvoll[0][1],Montagvoll[1][1], Montagvoll[2][1],Montagvoll[3][1],Montagvoll[4][1]]
M3c=[Montagvoll[0][2],Montagvoll[1][2], Montagvoll[2][2],Montagvoll[3][2],Montagvoll[4][2]]
M3d=[Montagvoll[0][3],Montagvoll[1][3], Montagvoll[2][3],Montagvoll[3][3],Montagvoll[4][3]]
M3e=[Montagvoll[0][4],Montagvoll[1][4], Montagvoll[2][4],Montagvoll[3][4],Montagvoll[4][4]]

print(M3a)
print(M3b)
print(M3c)
print(M3d)
print(M3e)



