import csv
import random


def istteilliste(lang, kurz):  # überprüft ob eine Liste eine "Teilmenge" von einer anderen ist
    x = 0
    for k in kurz:
        for l in lang:
            if k == l:
                x += 1
    if x == len(kurz):
        return True
    else:
        return False


def consistency(Wochevoll, Wocheleer, lek, kurse, tg, uhr, raum):
    if Wocheleer[tg][uhr][0][1] == 4 or Wocheleer[tg][uhr][0][1] == 5 or Wocheleer[tg][uhr][0][
        1] == 6:  # falls es sich um eine Mittag lektion handelt
        if Wocheleer[tg][uhr][0][1] == 4:
            for std in Wochevoll[Wocheleer[tg][uhr][0][0]][5][:]:
                for sch in std[2]:
                    for s in lek[
                        2]:  # und das schon die zweite Mittagslektion ist die ein Schueler an diesem Tag belegt
                        if s == sch:
                            for z in Wocheleer[tg][
                                     :]:  # dann sollte die dritte Mittagslektion nicht vom Schüler belegt werden.
                                if z[0][1] == 6:
                                    for k in z[:]:
                                        if s in k[2]:
                                            z.remove(k)
                for leh in std[1]:  # Das selbe gilt für lehrer
                    for l in lek[1]:
                        if l == leh:
                            for z in Wocheleer[tg]:
                                if z[0][1] == 4:
                                    for k in z[:]:
                                        if k[0] != Wocheleer[tg][uhr][0][0]:
                                            if l in k[1]:
                                                z.remove(k)
            for std in Wochevoll[Wocheleer[tg][uhr][0][0]][6]:  # Siehe Zeile 22
                for sch in std[2]:
                    for s in lek[2]:
                        if s == sch:
                            for z in Wocheleer[tg]:
                                if z[0][1] == 5:
                                    for k in z[:]:
                                        if s in k[2]:
                                            z.remove(k)
                for leh in std[1]:
                    for l in lek[1]:
                        if l == leh:
                            for z in Wocheleer[tg]:
                                if z[0][1] == 5:
                                    for k in z[:]:
                                        if k[0] != Wocheleer[tg][uhr][0][0]:
                                            if l in k[1]:
                                                z.remove(k)

        if Wocheleer[tg][uhr][0][1] == 5:  # siehe Zeile 22
            for std in Wochevoll[Wocheleer[tg][uhr][0][0]][4]:
                for sch in std[2]:
                    for s in lek[2]:
                        if s == sch:
                            for z in Wocheleer[tg]:
                                if z[0][1] == 6:
                                    for k in z[:]:
                                        if s in k[2]:
                                            z.remove(k)
                for leh in std[1]:
                    for l in lek[1]:
                        if l == leh:
                            for z in Wocheleer[tg]:
                                if z[0][1] == 6:
                                    for k in z[:]:
                                        if k[0] != Wocheleer[tg][uhr][0][0]:
                                            if l in k[1]:
                                                z.remove(k)
            for std in Wochevoll[Wocheleer[tg][uhr][0][0]][6]:
                for sch in std[2]:
                    for s in lek[2]:
                        if s == sch:
                            for z in Wocheleer[tg]:
                                if z[0][1] == 4:
                                    for k in z[:]:
                                        if s in k[2]:
                                            z.remove(k)
                for leh in std[1]:
                    for l in lek[1]:
                        if l == leh:
                            for z in Wocheleer[tg]:
                                if z[0][1] == 4:
                                    for k in z[:]:
                                        if k[0] != Wocheleer[tg][uhr][0][0]:
                                            if l in k[1]:
                                                z.remove(k)
        if Wocheleer[tg][uhr][0][1] == 6:
            for std in Wochevoll[Wocheleer[tg][uhr][0][0]][4]:
                for sch in std[2]:
                    for s in lek[2]:
                        if s == sch:
                            for z in Wocheleer[tg]:
                                if z[0][1] == 5:
                                    for k in z[:]:
                                        if s in k[2]:
                                            z.remove(k)
                for leh in std[1]:
                    for l in lek[1]:
                        if l == leh:
                            for z in Wocheleer[tg]:
                                if z[0][1] == 5:
                                    for k in z[:]:
                                        if k[0] != Wocheleer[tg][uhr][0][0]:
                                            if l in k[1]:
                                                z.remove(k)
            for std in Wochevoll[Wocheleer[tg][uhr][0][0]][5]:
                for sch in std[2]:
                    for s in lek[2]:
                        if s == sch:
                            for z in Wocheleer[tg]:
                                if z[0][1] == 4:
                                    for k in z[:]:
                                        if s in k[2]:
                                            z.remove(k)
                for leh in std[1]:
                    for l in lek[1]:
                        if l == leh:
                            for z in Wocheleer[tg]:
                                if z[0][1] == 4:
                                    for k in z[:]:
                                        if k[0] != Wocheleer[tg][uhr][0][0]:
                                            if l in k[1]:
                                                z.remove(k)
    lek.append(raum)
    ind = 0
    for f in Wocheleer[tg][uhr][len(Wocheleer[tg][uhr]) - 1][:]:
        if raum in f[:]:
            ind = Wocheleer[tg][uhr][len(Wocheleer[tg][uhr]) - 1].index(f)
            f.remove(raum)
    if not Wocheleer[tg][uhr][len(Wocheleer[tg][uhr]) - 1][ind]:
        for lektion in Wocheleer[tg][uhr][:]:
            if len(lektion) >= 4:
                if lektion[3] in faecher[ind]:
                    Wocheleer[tg][uhr].remove(lektion)

    for k in Wocheleer[tg][uhr][:]:
        for l in lek[1]:
            if isinstance(k[1], str):
                if l in k[1]:  # falls der selbe lehrer
                    Wocheleer[tg][uhr].remove(k)
        for s in lek[2][
                 :]:  # oder Schüler um diese selbe Uhrzeit noch einen Möglichen Kurs hat wird dieser gelöscht aus den Möcglichkeiten
            for sin in k[2][:]:
                if s == sin:
                    if k in Wocheleer[tg][uhr]:
                        Wocheleer[tg][uhr].remove(k)

    for x in kurse[:]:  # falls ein Kurs schon genugt oft statt gefunden hat wird er aus allen Möglichkeiten entfernt
        if x == lek:
            x[0] -= 1
        if x[0] == 0:
            kurse.remove(x)
            for d in Wocheleer:
                for h in d:
                    if x in h:
                        h.remove(x)



Klassen = []
with open('Schueler.csv',
          encoding="latin1") as csvDataFile:  # hier wierd eine Liste mit allen möglichen Klassen gemacht
    csvReader = csv.reader(csvDataFile, delimiter=";")
    for row in csvReader:
        Klassen.append(row[1])

klassen = set(Klassen)  # Alle Klassen die doppelt oder dreifach vorkommen werden hier entfehrnt
M1 = []
M2 = []
M3 = []
M4 = []
F1 = []
F2 = []
F3 = []
jahrgänge = ['M1', 'M2', 'M3', 'M4', 'F1', 'F2', 'F3']  # dies dient für die Sonderkurse die ganze Jahrgänge betreffen
for k in klassen:
    vars()[k] = []  # Hier werden die Klassenlisten erstellt
    if 'M' in k:
        if '1' in k:
            M1.append(k)
        if '2' in k:
            M2.append(k)
        if '3' in k:
            M3.append(k)
        if '4' in k:
            M4.append(k)
    if 'F' in k:
        if '1' in k:
            F1.append(k)
        if '2' in k:
            F2.append(k)
        if '3' in k:
            F3.append(k)

with open('Schueler.csv', encoding="latin1") as csvDataFile:
    csvReader = csv.reader(csvDataFile, delimiter=";")  # Schueler werden in die Klassenliesten angefügt
    for row in csvReader:
        vars()[row[1]].append(row[0])
kurse = []
with open('Kopie_von_Regelkurse.csv', encoding="latin1") as csvDataFile:  # Hier werden die Kurs Listen gemacht
    csvReader = csv.reader(csvDataFile, delimiter=";")
    for row in csvReader:
        l = row[9].replace(',', '')
        lehrer = l.split()
        k = row[8].replace(',', '')
        klass = k.split()
        kurs = vars()[row[0].replace('-', '')] = [int(row[4]), lehrer, []]
        if istteilliste(klassen,
                        klass):  # Es gib gemischte und ganze klassen. Wenn eine ganze klasse oder mehrere ganze
            # Klassen in einem Kurs soll es einfach die Klassenliste als kurs übernehmen.
            for x in klass:
                for s in vars()[x]:
                    kurs[2].append(s)
        else:  # wenn es keine ganzen Klassen sind soll es einfach die vorbereitet Kursliste übernehmen.
            for s in range(13, len(row) - 1):
                if row[s] != '':
                    kurs[2].append(row[s])
        kurs.append(row[2])
        if kurs[0] != 0:
            kurse.append(kurs)
sonderkurse = []
with open('Sonderkursemeh.csv', encoding="latin1") as csvDataFile:  # Hier werden die Sonderkurslisten gemacht
    csvReader = csv.reader(csvDataFile, delimiter=";")
    for row in csvReader:
        l = row[3]
        lehrer = l.split()
        k = row[2]
        klass = k.split()
        kurs = vars()[row[0]] = [[], [[], lehrer, []],[]]
        if istteilliste(klassen,
                        klass):  # bei den Freifächenr sind oft bestimmte Klassen betroffen
            for x in klass:
                for s in vars()[x]:
                    kurs[1][2].append(s)
        if istteilliste(jahrgänge,
                        klass):  # Sonderkurse die ganze JAhrgänge betreffen
            for x in klass:
                for sch in vars()[x]:
                    for s in vars()[sch]:
                        kurs[1][2].append(s)
        kurs[0].append(int(row[4]))  # in dieser
        kurs[0].append(int(row[5]))  # und dieser Zeile wird der Zeit Punkt des Kurses festgelegt
        kurs[1].append(row[1])
        kurs[2].append(row[6].split())
        sonderkurse.append(kurs)
raeume = []
with open('Raeume.csv', encoding="latin1") as csvDataFile: # raeume wird erstellt
    csvReader = csv.reader(csvDataFile, delimiter=";")
    for row in csvReader:
        vars()[row[0]] = []
        for r in range(1, len(row) - 1):
            if row[r] != '':
                vars()[row[0]].append(row[r])
        raeume.append(vars()[row[0]])
faecher = []
with open('Faecher.csv', encoding="latin1") as csvDataFile: # faecher wird erstellt
    csvReader = csv.reader(csvDataFile, delimiter=";")
    for row in csvReader:
        vars()[row[0]] = [int(row[1])]
        for r in range(2, len(row) - 1):
            if row[r] != '':
                vars()[row[0]].append(row[r])
        faecher.append(vars()[row[0]])
Tage = 5
Stunden = 12
Wocheleer = []  # Mögliche Lektionen
Wochevoll = []  # Festgelegte  Lektionen

S_01 = []
for x in range(Tage): #Wochenpläne werden erstellt
    Wocheleer.append([])
    Wochevoll.append([])
    for m in range(Stunden):
        Wochevoll[x].append([])
        Wocheleer[x].append([[x, m, 'xxx']])
        for k in kurse:
            Wocheleer[x][m].append(k)
            if k == kurse[-1]:
                Wocheleer[x][m].append([])
        for f in raeume:
            Wocheleer[x][m][-1].append([])
            for r in f:
                Wocheleer[x][m][-1][-1].append(r)

for sk in sonderkurse: # Sonder Kurse werden gelegt
    Wochevoll[sk[0][0]][sk[0][1]].append(sk[1])
    for r in sk[2]:
       consistency(Wochevoll, Wocheleer, sk[1], kurse, sk[0][0], sk[0][1],r)

while len(Wocheleer) != 0:
    if len(Wocheleer) >= 1:  # an einem Zufälligen Tag
        tg = random.randint(0, len(Wocheleer) - 1)
    else:
        tg = 0
    if len(Wocheleer[tg]) >= 1:  # zu einer zufälligen Zeit
        uhr = random.randint(0, len(Wocheleer[tg]) - 1)
    else:
        uhr = 0
    if len(Wocheleer[tg][uhr]) >= 2:  # wählt ich eine Mölgliche Lektion
        lek = Wocheleer[tg][uhr][random.randint(1, len(Wocheleer[tg][uhr]) - 2)]
    else:
        lek = Wocheleer[tg][uhr][1]
    for f in faecher:
        if lek[3] in f: #Raum wird gewählt
            if len(Wocheleer[tg][uhr][-1][f[0]]) >= 1:
                raum = Wocheleer[tg][uhr][len(Wocheleer[tg][uhr]) - 1][f[0]][
                    random.randint(0, len(Wocheleer[tg][uhr][-1][f[0]]) - 1)]
            else:
                raum = Wocheleer[tg][uhr][-1][f[0]][0]
    consistency(Wochevoll, Wocheleer, lek, kurse, tg, uhr, raum)
    # Es wird überprüft ob eine Doppellektion Möglich ist
    if lek[0] >= 1 and Wocheleer[tg][uhr - 1][0][1] == Wocheleer[tg][uhr][0][1] - 1 and lek in Wocheleer[tg][uhr - 1]:
        Wochevoll[Wocheleer[tg][uhr - 1][0][0]][Wocheleer[tg][uhr - 1][0][1]].append(lek)
        consistency(Wochevoll, Wocheleer, lek, kurse, tg, uhr - 1, raum)
    else:
        if len(Wocheleer[tg]) >= Wocheleer[tg].index(Wocheleer[tg][uhr]) + 2:
            if lek[0] >= 1 and Wocheleer[tg][uhr + 1][0][1] == Wocheleer[tg][uhr][0][1] + 1 and lek in Wocheleer[tg][
                uhr + 1]:
                Wochevoll[Wocheleer[tg][uhr + 1][0][0]][Wocheleer[tg][uhr + 1][0][1]].append(lek)
                consistency(Wochevoll, Wocheleer, lek, kurse, tg, uhr + 1, raum)
    Wochevoll[Wocheleer[tg][uhr][0][0]][Wocheleer[tg][uhr][0][1]].append(lek)  # diese wird festgelegt

    for z in Wocheleer[tg]:
        for k in z[:]:
            if lek == k:
                z.remove(k)

    for x in Wocheleer[
             :]:  # falls es keine Möglichkeiten mehr gibt um eine Uhrzeit oder Tag, wird dieser Tag oder Uhrzeit als möglichkeit entfernt
        for u in x[:]:
            if len(u) == 2:
                x.remove(u)
            if len(x) == 0:
                Wocheleer.remove(x)


S_01 = [] # Ab hier werden Stichproben erstellt
S_02 = []
S_03 = []
S_04 = []
S_05 = []

S = ['S_01', 'S_02', 'S_03', 'S_04', 'S_05']
for sch in S:
    for x in range(Tage):
        vars()[sch].append([])
        for m in range(Stunden):
            vars()[sch][x].append([])

for sch in S:
    for t in Wochevoll:
        for h in t:
            for k in h:
                if sch in k[2]:
                    vars()[sch][Wochevoll.index(t)][t.index(h)].append(k[3])
                    vars()[sch][Wochevoll.index(t)][t.index(h)].append(k[4])


for sch in S:
    for t in vars()[sch]:
        print(t)
    print('__________________________________________________________________________________________')

for x in kurse:
    print(x)
print(len(kurse))