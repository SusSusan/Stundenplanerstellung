import csv
import random
import copy
from typing import List, Any

import kur as kur


def istteilliste(lang, kurz):  # überprüft ob eine Liste eine "Teilmenge" von einer anderen ist
    x = 0
    for k in kurz:
        for l in lang:
            if k == l:
                x += 1
    if x == len(kurz):
        return True
    else:
        return False


def consistency(Wochevoll, Wocheleer, lek, kurse, tg, uhr, raum):
    if Wocheleer[tg][uhr][0][1] == 4 or Wocheleer[tg][uhr][0][1] == 5 or Wocheleer[tg][uhr][0][
        1] == 6:  # falls es sich um eine Mittag lektion handelt
        if Wocheleer[tg][uhr][0][1] == 4:
            for std in Wochevoll[Wocheleer[tg][uhr][0][0]][5][:]:
                for sch in std[2]:
                    for s in lek[
                        2]:  # und das schon die zweite Mittagslektion ist die ein Schueler an diesem Tag belegt
                        if s == sch:
                            for z in Wocheleer[tg][
                                     :]:  # dann sollte die dritte Mittagslektion nicht vom Schüler belegt werden.
                                if z[0][1] == 6:
                                    for k in z[:]:
                                        if s in k[2]:
                                            z.remove(k)
                for leh in std[1]:  # Das selbe gilt für lehrer
                    for l in lek[1]:
                        if l == leh:
                            for z in Wocheleer[tg]:
                                if z[0][1] == 6:
                                    for k in z[:]:
                                        if k[0] != Wocheleer[tg][uhr][0][0]:
                                            if l in k[1]:
                                                z.remove(k)
            for std in Wochevoll[Wocheleer[tg][uhr][0][0]][6]:  # Siehe Zeile 22
                for sch in std[2]:
                    for s in lek[2]:
                        if s == sch:
                            for z in Wocheleer[tg]:
                                if z[0][1] == 5:
                                    for k in z[:]:
                                        if s in k[2]:
                                            z.remove(k)
                for leh in std[1]:
                    for l in lek[1]:
                        if l == leh:
                            for z in Wocheleer[tg]:
                                if z[0][1] == 5:
                                    for k in z[:]:
                                        if k[0] != Wocheleer[tg][uhr][0][0]:
                                            if l in k[1]:
                                                z.remove(k)

        if Wocheleer[tg][uhr][0][1] == 5:  # siehe Zeile 22
            for std in Wochevoll[Wocheleer[tg][uhr][0][0]][4]:
                for sch in std[2]:
                    for s in lek[2]:
                        if s == sch:
                            for z in Wocheleer[tg]:
                                if z[0][1] == 6:
                                    for k in z[:]:
                                        if s in k[2]:
                                            z.remove(k)
                for leh in std[1]:
                    for l in lek[1]:
                        if l == leh:
                            for z in Wocheleer[tg]:
                                if z[0][1] == 6:
                                    for k in z[:]:
                                        if k[0] != Wocheleer[tg][uhr][0][0]:
                                            if l in k[1]:
                                                z.remove(k)
            for std in Wochevoll[Wocheleer[tg][uhr][0][0]][6]:
                for sch in std[2]:
                    for s in lek[2]:
                        if s == sch:
                            for z in Wocheleer[tg]:
                                if z[0][1] == 4:
                                    for k in z[:]:
                                        if s in k[2]:
                                            z.remove(k)
                for leh in std[1]:
                    for l in lek[1]:
                        if l == leh:
                            for z in Wocheleer[tg]:
                                if z[0][1] == 4:
                                    for k in z[:]:
                                        if k[0] != Wocheleer[tg][uhr][0][0]:
                                            if l in k[1]:
                                                z.remove(k)
        if Wocheleer[tg][uhr][0][1] == 6:
            for std in Wochevoll[Wocheleer[tg][uhr][0][0]][4]:
                for sch in std[2]:
                    for s in lek[2]:
                        if s == sch:
                            for z in Wocheleer[tg]:
                                if z[0][1] == 5:
                                    for k in z[:]:
                                        if s in k[2]:
                                            z.remove(k)
                for leh in std[1]:
                    for l in lek[1]:
                        if l == leh:
                            for z in Wocheleer[tg]:
                                if z[0][1] == 5:
                                    for k in z[:]:
                                        if k[0] != Wocheleer[tg][uhr][0][0]:
                                            if l in k[1]:
                                                z.remove(k)
            for std in Wochevoll[Wocheleer[tg][uhr][0][0]][5]:
                for sch in std[2]:
                    for s in lek[2]:
                        if s == sch:
                            for z in Wocheleer[tg]:
                                if z[0][1] == 4:
                                    for k in z[:]:
                                        if s in k[2]:
                                            z.remove(k)
                for leh in std[1]:
                    for l in lek[1]:
                        if l == leh:
                            for z in Wocheleer[tg]:
                                if z[0][1] == 4:
                                    for k in z[:]:
                                        if k[0] != Wocheleer[tg][uhr][0][0]:
                                            if l in k[1]:
                                                z.remove(k)
    ind = 0
    for f in faecher[:]:  # Falls ein alle Zimmer in denen ein Kurs stattfinden kann besetzt ist
        if lek[3] in f[:]:
            ind = f[0]
            if raum in Wocheleer[tg][uhr][len(Wocheleer[tg][uhr]) - 1][ind]:
                Wocheleer[tg][uhr][len(Wocheleer[tg][uhr]) - 1][ind].remove(raum)
    if Wocheleer[tg][uhr][len(Wocheleer[tg][uhr]) - 1][ind] == []:  # wird dieser Kurs gestrichen
        for lektion in Wocheleer[tg][uhr][:]:
            if len(lektion) >= 4:
                if lektion[3] in faecher[ind]:
                    Wocheleer[tg][uhr].remove(lektion)
    # for f in Wocheleer[tg][uhr][len(Wocheleer[tg][uhr]) - 1][:]:
    #   if raum in f[:]:
    #      ind = Wocheleer[tg][uhr][len(Wocheleer[tg][uhr]) - 1].index(f)
    #     f.remove(raum)
    # if not Wocheleer[tg][uhr][len(Wocheleer[tg][uhr]) - 1][ind]:
    # for lektion in Wocheleer[tg][uhr][:]:
    #   if len(lektion) >= 4:
    #      if lektion[3] in faecher[ind]:
    #         Wocheleer[tg][uhr].remove(lektion)

    for k in Wocheleer[tg][uhr][:]:
        for l in lek[1]:
            if isinstance(k[1], str):
                if l in k[1]:  # falls der selbe lehrer
                    Wocheleer[tg][uhr].remove(k)
        for s in lek[2][
                 :]:  # oder Schüler um diese selbe Uhrzeit noch einen Möglichen Kurs hat wird dieser gelöscht aus
            # den Möcglichkeiten
            for sin in k[2][:]:
                if s == sin:
                    if k in Wocheleer[tg][uhr]:
                        Wocheleer[tg][uhr].remove(k)

    if kurse[0][0]:
        for x in kurse[
                 :]:  # falls ein Kurs schon genugt oft statt gefunden hat wird er aus allen Möglichkeiten entfernt
            if x == lek:
                x[0] -= 1
            if x[0] == 0:
                kurse.remove(x)
                for d in Wocheleer:
                    for h in d:
                        if x in h:
                            h.remove(x)


schueler = []
Klassen = []
with open('Schueler.csv',
          encoding="latin1") as csvDataFile:  # hier wierd eine Liste mit allen möglichen Klassen gemacht
    csvReader = csv.reader(csvDataFile, delimiter=";")
    for row in csvReader:
        Klassen.append(row[1])
        schueler.append(row[0])

klassen = set(Klassen)  # Alle Klassen die doppelt oder dreifach vorkommen werden hier entfehrnt
M1 = []
M2 = []
M3 = []
M4 = []
F1 = []
F2 = []
F3 = []
jahrgänge = ['M1', 'M2', 'M3', 'M4', 'F1', 'F2', 'F3']  # dies dient für die Sonderkurse die ganze Jahrgänge betreffen
for k in klassen:
    vars()[k] = []  # Hier werden die Klassenlisten erstellt
    if 'M' in k:
        if '1' in k:
            M1.append(k)
        if '2' in k:
            M2.append(k)
        if '3' in k:
            M3.append(k)
        if '4' in k:
            M4.append(k)
    if 'F' in k:
        if '1' in k:
            F1.append(k)
        if '2' in k:
            F2.append(k)
        if '3' in k:
            F3.append(k)

with open('Schueler.csv', encoding="latin1") as csvDataFile:
    csvReader = csv.reader(csvDataFile, delimiter=";")  # Schueler werden in die Klassenliesten angefügt
    for row in csvReader:
        vars()[row[1]].append(row[0])
lehrerinnen = []
kurse = [[True]]
with open('Kopie_von_Regelkurse.csv', encoding="latin1") as csvDataFile:  # Hier werden die Kurs Listen gemacht
    csvReader = csv.reader(csvDataFile, delimiter=";")
    for row in csvReader:
        l = row[9].replace(',', '')
        lehrer = l.split()
        k = row[8].replace(',', '')
        klass = k.split()
        kurs = vars()[row[0].replace('-', '')] = [int(row[4]), lehrer, []]
        if istteilliste(klassen,
                        klass):  # Es gib gemischte und ganze klassen. Wenn eine ganze klasse oder mehrere ganze
            # Klassen in einem Kurs soll es einfach die Klassenliste als kurs übernehmen.
            for x in klass:
                for s in vars()[x]:
                    kurs[2].append(s)
        else:  # wenn es keine ganzen Klassen sind soll es einfach die vorbereitet Kursliste übernehmen.
            for s in range(13, len(row) - 1):
                if row[s] != '':
                    kurs[2].append(row[s])
        kurs.append(row[2])
        if kurs[0] != 0:
            kurse.append(kurs)
        for x in lehrer:
            if x not in lehrerinnen:
                lehrerinnen.append(x)
sonderkurse = []
with open('Sonderkursemeh.csv', encoding="latin1") as csvDataFile:  # Hier werden die Sonderkurslisten gemacht
    csvReader = csv.reader(csvDataFile, delimiter=";")
    for row in csvReader:
        l = row[3]
        lehrer = l.split()
        k = row[2]
        klass = k.split()
        kurs = vars()[row[0]] = [[], [[], lehrer, []], []]
        if istteilliste(klassen,
                        klass):  # bei den Freifächenr sind oft bestimmte Klassen betroffen
            for x in klass:
                for s in vars()[x]:
                    kurs[1][2].append(s)
        if istteilliste(jahrgänge,
                        klass):  # Sonderkurse die ganze JAhrgänge betreffen
            for x in klass:
                for sch in vars()[x]:
                    for s in vars()[sch]:
                        kurs[1][2].append(s)
        kurs[0].append(int(row[4]))  # in dieser
        kurs[0].append(int(row[5]))  # und dieser Zeile wird der Zeit Punkt des Kurses festgelegt
        kurs[1].append(row[1])
        kurs[2].append(row[6].split())
        sonderkurse.append(kurs)
raeume = []
with open('Raeume.csv', encoding="latin1") as csvDataFile:  # raeume wird erstellt
    csvReader = csv.reader(csvDataFile, delimiter=";")
    for row in csvReader:
        vars()[row[0]] = []
        for r in range(1, len(row) - 1):
            if row[r] != '':
                vars()[row[0]].append(row[r])
        raeume.append(vars()[row[0]])
faecher = []
with open('Faecher.csv', encoding="latin1") as csvDataFile:  # faecher wird erstellt
    csvReader = csv.reader(csvDataFile, delimiter=";")
    for row in csvReader:
        vars()[row[0]] = [int(row[1])]
        for r in range(2, len(row) - 1):
            if row[r] != '':
                vars()[row[0]].append(row[r])
        faecher.append(vars()[row[0]])
Tage = 5
Stunden = 12
Wocheleer = []  # Mögliche Lektionen
Wochevoll = []  # Festgelegte  Lektionen
Immernoch = []
kurse2 = copy.deepcopy(kurse)
for x in kurse2:
    x[0] = 0
kurse2[0][0] = False

for x in range(Tage):  # Die Wochenpläne werden ersttelt
    Wocheleer.append([])
    Wochevoll.append([])
    Immernoch.append([])
    for m in range(Stunden):
        Wochevoll[x].append([])
        Wocheleer[x].append([[x, m, 'xxx']])  # Uhrzeit-Koordinate
        Immernoch[x].append([])
        Immernoch[x][m].append(copy.deepcopy([*schueler, *lehrerinnen]))
        for k in kurse:
            if len(k) != 1:
                Wocheleer[x][m].append(k)
                if k == kurse[-1]:
                    Wocheleer[x][m].append([])
        for k in kurse2:
            if len(k) != 1:
                Immernoch[x][m].append(k)
        for f in raeume:
            Wocheleer[x][m][-1].append([])
            for r in f:
                Wocheleer[x][m][-1][-1].append(r)
        Immernoch[x][m].append(copy.deepcopy(raeume))

for sk in sonderkurse:  # Sonderkurse werden gelegt
    for r in sk[2]:
        Wochevoll[sk[0][0]][sk[0][1]].append(sk[1])
        consistency(Wochevoll, Wocheleer, sk[1], kurse, sk[0][0], sk[0][1], r)
        consistency(Wochevoll, Immernoch, sk[1], kurse2, sk[0][0], sk[0][1], r)

while len(Wocheleer) != 0:
    if len(Wocheleer) >= 1:  # an einem Zufälligen Tag
        tg = random.randint(0, len(Wocheleer) - 1)
    else:
        tg = 0
    if len(Wocheleer[tg]) >= 1:  # zu einer zufälligen Zeit
        uhr = random.randint(0, len(Wocheleer[tg]) - 1)
    else:
        uhr = 0
    if len(Wocheleer[tg][uhr]) >= 2:  # wählt ich eine Mölgliche Lektion
        lek = Wocheleer[tg][uhr][random.randint(1, len(Wocheleer[tg][uhr]) - 2)]
    else:
        lek = Wocheleer[tg][uhr][1]
    for f in faecher:
        if lek[3] in f:
            if len(Wocheleer[tg][uhr][len(Wocheleer[tg][uhr]) - 1][f[0]]) >= 1:
                raum = Wocheleer[tg][uhr][len(Wocheleer[tg][uhr]) - 1][f[0]][
                    random.randint(0, len(Wocheleer[tg][uhr][len(Wocheleer[tg][uhr]) - 1][f[0]]) - 1)]
            else:
                raum = Wocheleer[tg][uhr][len(Wocheleer[tg][uhr]) - 1][f[0]][0]
    consistency(Wochevoll, Wocheleer, lek, kurse, tg, uhr, raum)
    consistency(Wochevoll, Immernoch, lek, kurse2, tg, uhr, raum)
    lek2 = copy.deepcopy(lek)
    lek2.append(raum)
    lek2[0] = 0
    # Es wird in der nächstenn Zeilen auf Doppellektionen geprüft
    if lek[0] >= 1 and Wocheleer[tg][uhr - 1][0][1] == Wocheleer[tg][uhr][0][1] - 1 and lek in Wocheleer[tg][uhr - 1]:
        Wochevoll[Wocheleer[tg][uhr - 1][0][0]][Wocheleer[tg][uhr - 1][0][1]].append(lek2)
        consistency(Wochevoll, Wocheleer, lek, kurse, tg, uhr - 1, raum)
        consistency(Wochevoll, Immernoch, lek, kurse2, tg, uhr - 1, raum)
    else:
        if len(Wocheleer[tg]) >= Wocheleer[tg].index(Wocheleer[tg][uhr]) + 2:
            if lek[0] >= 1 and Wocheleer[tg][uhr + 1][0][1] == Wocheleer[tg][uhr][0][1] + 1 and lek in Wocheleer[tg][
                uhr + 1]:
                Wochevoll[Wocheleer[tg][uhr + 1][0][0]][Wocheleer[tg][uhr + 1][0][1]].append(lek2)
                consistency(Wochevoll, Wocheleer, lek, kurse, tg, uhr + 1, raum)
                consistency(Wochevoll, Immernoch, lek, kurse2, tg, uhr + 1, raum)

    Wochevoll[Wocheleer[tg][uhr][0][0]][Wocheleer[tg][uhr][0][1]].append(lek2)  # diese wird festgelegt
    for z in Wocheleer[tg]: # Damit eine Lektion nicht zu verschiedenen Uhrzeiten am selben Tag Statt findet
        for k in z[:]:
            if lek == k:
                z.remove(k)
    for z in Immernoch[tg]:
        for k in z[:]:
            if lek == k:
                z.remove(k)

    for x in Wocheleer[
             :]:  # falls es keine Möglichkeiten mehr gibt um eine Uhrzeit oder Tag, wird dieser Tag oder Uhrzeit als
        # möglichkeit entfernt
        for u in x[:]:
            if len(u) == 2:
                x.remove(u)
            if len(x) == 0:
                Wocheleer.remove(x)

kurse.remove(kurse[0])
kurse2.remove(kurse2[0])
for tag in Immernoch: # Die Lieste von freien SchülerInnen wird erstellt
    for zeit in Immernoch:
        for kurs in Immernoch:
            if len(kurs) == 4 or len(kurs)== 5:
                for sch in kurs[2]:
                    zeit[0].remove(sch)
                for l in kurs[1]:
                    zeit[0].remove(l)
kurse3 = []
for x in kurse2[:]: # Hier Wir sicher gesttellt dass es genug möglichketen gibt einen Kurs zuverschieben.
    z = 0
    for t in Immernoch:
        for h in t:
            if x in h:
                z += 1
    if z <= 4:
        kurse2.remove(x)
    x[0] = 0
for kurs in kurse: #nauer Platz für übrigen Kurs wird gesucht
    found = False
    for tag in range(Tage):
        if found:
            break
        for zeit in range(Stunden):
            if found:
                break
            for lek in Wochevoll[tag][zeit]:
                if istteilliste([*lek[2], *lek[1], *Immernoch[tag][zeit][0]],
                                [*kurs[1], *kurs[2]]) and [lek[0], lek[1], lek[2],
                                                           lek[3]] in kurse2:  # ist der Raum auch frei?
                    for sch in lek[2]:
                        if sch not in kurs[2]:
                            Immernoch[tag][zeit].append(sch)
                    for lehr in lek[1]:
                        if lehr not in kurs[1]:
                            Immernoch[tag][zeit].append(lehr)
                    Wochevoll[tag][zeit].remove(lek)
                    Wochevoll[tag][zeit].append(kurs)
                    lek.remove(lek[4])
                    kurse3.append(lek)
                    kurs[0] -= 1
                    if kurs[0] == 0:
                        found = True
                        break

for kurs in kurse3[:]: #Kurs wird an neuen Platz verschoben
    i = 0
    for tag in range(Tage):
        for zeit in range(Stunden):
            if kurs in Immernoch[tag][zeit]:
                i += 1
                if i == 1:
                    for f in faecher:
                        if kurs[3] in f:
                            if len(Immernoch[tag][zeit][len(Immernoch[tag][zeit]) - 1][f[0]]) >= 1:
                                raum = Immernoch[tag][zeit][-1][f[0]][
                                    random.randint(0, len(Immernoch[tag][zeit][-1][f[0]]) - 1)]
                            else:
                                raum = Immernoch[tg][uhr][-1][f[0]][0]
                kurs.append(raum)
                Wochevoll[tag][zeit].append(kurs)
                consistency(Wochevoll, Immernoch, kurs, kurse2, tag, zeit, raum)
                for z in Immernoch[tg]:
                    for k in z[:]:
                        if kurs == k:
                            z.remove(k)
                kurse3.remove(kurs)

S_01 = [] #ab hier werden Stichproben erstellt
S_02 = []
S_03 = []
S_04 = []
S_05 = []

S = ['S_01', 'S_02', 'S_03', 'S_04', 'S_05']
for sch in S:
    for x in range(Tage):
        vars()[sch].append([])
        for m in range(Stunden):
            vars()[sch][x].append([])

for sch in S:
    for t in Wochevoll:
        for h in t:
            for k in h:
                if sch in k[2]:
                    vars()[sch][Wochevoll.index(t)][t.index(h)].append(k[3])
                    if len(k) == 5:
                        vars()[sch][Wochevoll.index(t)][t.index(h)].append(k[4])

for sch in S:
    for t in vars()[sch]:
        print(t)
    print('__________________________________________________________________________________________')

print(len(kurse3))
